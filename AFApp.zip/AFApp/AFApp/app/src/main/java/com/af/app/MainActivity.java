package com.af.app;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    Context ctx;
    TextView nodata;
    ListView list;
    CardsAdapter adapter;
    Button btn1;
    ArrayList<HashMap<String, String>> eCards = new ArrayList<>();
    int loadcount = 0;
    Bitmap bmps[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ctx = this;
        setContentView(R.layout.activity_main);
        list = (ListView) findViewById(R.id.list);
        adapter = new CardsAdapter(ctx);
        list.setAdapter(adapter);
        if (iO())
            new GetCards().execute("https://www.abercrombie.com/anf/nativeapp/qa/codetest/codeTest_exploreData.json");
        else {
            AlertDialog.Builder dialog = new AlertDialog.Builder(ctx);
            dialog.setTitle("Sorry!");
            dialog.setMessage("Please check your internet.");
            dialog.setNeutralButton("OK", null);
            dialog.create().show();
        }
    }

    boolean iO() {
        try {
            Process p1 = Runtime.getRuntime().exec("ping -c 1    www.google.com");
            int returnVal = p1.waitFor();
            boolean reachable = (returnVal == 0);
            if (reachable)
                return reachable;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public class GetCards extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        public void onPreExecute() {
            pd = createProgressDialog(ctx);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String res = getSourceCode(params[0]);
            return res;
        }

        String getSourceCode(String requestURL) {
            String response = "";
            try {
                URL url = new URL(requestURL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    String line;
                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    while ((line = br.readLine()) != null) {
                        response += line;
                    }
                } else {
                    response = "";
                }
            } catch (IOException e) {
                e.printStackTrace();
                return response;
            }
            return response;
        }

        @Override
        public void onPostExecute(String result) {
            super.onPostExecute(result);
            if (pd != null) {
                if (pd.isShowing())
                    pd.dismiss();
            }
            try {
                eCards.clear();
                JSONArray jsonArray = new JSONArray(result);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    HashMap<String, String> values = new HashMap<>();
                    values.put("title", jsonObject.optString("title").toString());
                    values.put("backgroundImage", jsonObject.optString("backgroundImage").toString());
                    values.put("promoMessage", jsonObject.optString("promoMessage").toString());
                    values.put("topDescription", jsonObject.optString("topDescription").toString());
                    values.put("bottomDescription", jsonObject.optString("bottomDescription").toString());
                    JSONArray tempjArray = jsonObject.optJSONArray("content");
                    if (tempjArray != null) {
                        for (int j = 0; j < tempjArray.length(); j++) {
                            JSONObject jsontempObject = tempjArray.getJSONObject(j);
                            values.put("subtitle" + j, jsontempObject.optString("title"));
                            values.put("target" + j, jsontempObject.optString("target"));
                        }
                        values.put("sublength", tempjArray.length() + "");
                    }
                    eCards.add(values);
                }
                if (eCards.size() == 0) {
                    nodata.setVisibility(View.VISIBLE);
                    list.setVisibility(View.GONE);
                }
                loadBitmaps();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    public void loadBitmaps() {
        loadcount = 0;
        bmps = new Bitmap[eCards.size()];
        final ProgressDialog pd = createProgressDialog(ctx);
        pd.show();
        class LoadBitmaps extends AsyncTask<String, String, String> {

            @Override
            protected String doInBackground(String... params) {
                try {
                    URL url = new URL(eCards.get(loadcount).get("backgroundImage"));
                    Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    bmps[loadcount] = bmp;
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
                return "";
            }

            @Override
            public void onPostExecute(String result) {
                super.onPostExecute(result);
                ++loadcount;
                if (loadcount < eCards.size())
                    new LoadBitmaps().execute();
                else {
                    if (pd != null) {
                        if (pd.isShowing())
                            pd.dismiss();
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        }
        new LoadBitmaps().execute();
    }

    class CardsAdapter extends BaseAdapter {
        ImageView iv1;
        TextView tv1, tv2, tv3, tv4;
        LinearLayout my_layout1;
        LayoutInflater li;
        Context c;

        CardsAdapter(Context ct) {
            li = LayoutInflater.from(ct);
            c = ct;
        }

        @Override
        public int getCount() {
            try {
                return eCards.size();
            } catch (NullPointerException npe) {
                npe.printStackTrace();
                return 0;
            }
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            convertView = li.inflate(R.layout.list_item, null);
            iv1 = (ImageView) convertView.findViewById(R.id.iv1);
            tv1 = (TextView) convertView.findViewById(R.id.tv1);
            tv2 = (TextView) convertView.findViewById(R.id.tv2);
            tv3 = (TextView) convertView.findViewById(R.id.tv3);
            tv4 = (TextView) convertView.findViewById(R.id.tv4);
            my_layout1 = (LinearLayout) convertView.findViewById(R.id.my_layout1);
            try {
                if (Integer.parseInt(eCards.get(position).get("sublength")) > 0) {
                    my_layout1.setVisibility(View.VISIBLE);
                    my_layout1.removeAllViews();
                    for (int i = 0; i < Integer.parseInt(eCards.get(position).get("sublength")); i++) {
                        final int ai = i;
                        TableRow row = new TableRow(ctx);
                        row.setId(i);
                        row.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        btn1 = new Button(ctx);
                        btn1.setId(i);
                        btn1.setTextColor(Color.parseColor("#FFFFFF"));
                        btn1.setTextSize(15.0f);
                        btn1.setText(eCards.get(position).get("subtitle" + ai) + "");
                        TableRow.LayoutParams params = new TableRow.LayoutParams(
                                TableRow.LayoutParams.MATCH_PARENT,
                                TableRow.LayoutParams.WRAP_CONTENT
                        );
                        params.setMargins(5, 5, 5, 5);
                        btn1.setLayoutParams(params);
                        btn1.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
                        btn1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent i = new Intent(ctx, URLWebView.class);
                                i.putExtra("url", eCards.get(position).get("target" + ai));
                                startActivity(i);
                            }
                        });
                        btn1.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                        row.addView(btn1);
                        my_layout1.addView(row);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (!(position == eCards.size())) {
                if (eCards.get(position).get("backgroundImage").length() > 0) {
                    iv1.setImageBitmap(bmps[position]);
                    iv1.setVisibility(View.VISIBLE);
                }

                if (eCards.get(position).get("topDescription").length() > 0) {
                    tv1.setVisibility(View.VISIBLE);
                    tv1.setText(eCards.get(position).get("topDescription") + "");
                }
                if (eCards.get(position).get("title").length() > 0) {
                    tv2.setVisibility(View.VISIBLE);
                    tv2.setText(eCards.get(position).get("title") + "");
                }
                if (eCards.get(position).get("promoMessage").length() > 0) {
                    tv3.setVisibility(View.VISIBLE);
                    tv3.setText(eCards.get(position).get("promoMessage") + "");
                }
                final String tempbottomDesc = eCards.get(position).get("bottomDescription");
                if (tempbottomDesc.length() > 0) {
                    tv4.setVisibility(View.VISIBLE);
                    tv4.setText(Html.fromHtml(tempbottomDesc + ""));
                    if (tempbottomDesc.contains("href")) {
                        tv4.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent i = new Intent(ctx, URLWebView.class);
                                i.putExtra("url", tempbottomDesc.substring(tempbottomDesc.indexOf("http"),
                                        tempbottomDesc.indexOf(".html") + 5));
                                startActivity(i);
                            }
                        });
                    }
                }
            } else {
                Toast.makeText(ctx, "last line", Toast.LENGTH_LONG).show();
            }
            return convertView;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
    }

    ProgressDialog createProgressDialog(Context context) {
        ProgressDialog dialog = new ProgressDialog(context);
        try {
            dialog.show();
        } catch (WindowManager.BadTokenException e) {
            e.printStackTrace();
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.progressdialog);
        return dialog;
    }
}